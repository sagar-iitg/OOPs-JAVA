<h1>Recurrence Questions:</h1>
<p align="">
  <img src="https://github.com/crishabhkumar/crishabhkumar/blob/main/Extra%20images/Screenshot%20(46).png" width="322" title="hover text">
  <img src="https://github.com/crishabhkumar/crishabhkumar/blob/main/Extra%20images/Screenshot%20(47).png" width="350" title="hover text">
</p>

<h1>Akra Bazzi:</h1>
<p align="">
  <img src="https://github.com/crishabhkumar/crishabhkumar/blob/main/Extra%20images/Screenshot%20(48).png" width="322" title="hover text">
</p>

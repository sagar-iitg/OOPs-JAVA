package com.kunal.generics;

public interface GenericInterface<T> {
    void display(T value);
}

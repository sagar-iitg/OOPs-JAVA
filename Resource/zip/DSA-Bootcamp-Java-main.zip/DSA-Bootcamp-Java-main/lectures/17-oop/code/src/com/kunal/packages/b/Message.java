package com.kunal.packages.b;

public class Message {
    public static void main(String[] args) {

    }

    public static void message() {
        System.out.println("This course is awesome");
    }
}

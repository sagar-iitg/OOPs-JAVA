package com.kunal.properties.polymorphism;

public class Shapes {
    void area() {
        System.out.println("I am in shapes");
    }

//      Early binding: check notes
//    final void area() {
//        System.out.println("I am in shapes");
//    }
}

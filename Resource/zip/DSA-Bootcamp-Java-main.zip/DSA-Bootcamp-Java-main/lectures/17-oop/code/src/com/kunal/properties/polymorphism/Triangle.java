package com.kunal.properties.polymorphism;

public class Triangle extends Shapes{
    void area() {
        System.out.println("Area is 0.5 * h * b");
    }
}

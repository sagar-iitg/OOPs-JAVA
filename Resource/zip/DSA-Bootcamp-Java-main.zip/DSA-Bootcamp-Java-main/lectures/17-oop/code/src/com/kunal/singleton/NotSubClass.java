package com.kunal.singleton;

import com.kunal.access.A;

public class NotSubClass{


    public static void main(String[] args) {
        NotSubClass obj = new NotSubClass();
//        int n = obj.num;
    }
}
